# Redirection unique — Cloudflare Pages

## Fonctionnement
- Une seule destination configurée dans `/admin`.
- L'administration est protégée par un mot de passe.
- Choix d'un délai de 0 à 300 secondes et d'une confirmation facultative.
- Si le délai est à 0 et que la confirmation est désactivée, la redirection est immédiate.
- La configuration est stockée dans le KV Cloudflare.

## Déploiement
1. Décompressez l'archive et déployez `_worker.js` sur un projet Cloudflare Pages en mode Workers (Advanced Mode).
2. Dans **Settings > Bindings**, ajoutez un binding **KV namespace** nommé `LINKS`.
3. Dans **Settings > Variables and Secrets**, ajoutez les secrets :
   - `ADMIN_PASSWORD` : votre mot de passe d'administration.
   - `SESSION_SECRET` : une longue valeur aléatoire distincte (32 caractères ou plus).
4. Redéployez le projet.
5. Visitez `/admin`, connectez-vous et configurez l'URL cible.

Si une sauvegarde échoue, vérifiez que le binding KV `LINKS` est attaché à l'environnement réellement déployé (Production ou Preview). Cette version affiche une erreur lisible au lieu de laisser remonter une erreur 1101; les détails techniques restent dans les logs Cloudflare.

La page publique (racine du domaine) redirige ensuite selon les options enregistrées.
