// Redirection unique Cloudflare Pages — configuration via /admin
// Bindings Cloudflare Pages : KV "LINKS" ; secrets : ADMIN_PASSWORD, SESSION_SECRET
const enc = new TextEncoder();
const CONFIG_KEY = "single-redirect:config";
const COOKIE = "single_redirect_session";
const TITLE = "Redirection";
const esc = s => String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const json = (o, status=200, headers={}) => new Response(JSON.stringify(o), {status, headers:{"content-type":"application/json; charset=utf-8","cache-control":"no-store",...headers}});
async function mac(message, secret) {
  const key = await crypto.subtle.importKey("raw", enc.encode(secret), {name:"HMAC",hash:"SHA-256"}, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", key, enc.encode(message));
  return btoa(String.fromCharCode(...new Uint8Array(sig))).replace(/\+/g,"-").replace(/\//g,"_").replace(/=+$/,"");
}
function safeEqual(a,b) { if (a.length !== b.length) return false; let x=0; for(let i=0;i<a.length;i++) x |= a.charCodeAt(i)^b.charCodeAt(i); return x===0; }
async function hasSession(req, env) {
  const raw = (req.headers.get("Cookie")||"").split(";").map(x=>x.trim()).find(x=>x.startsWith(COOKIE+"="))?.slice(COOKIE.length+1);
  if (!raw || !env.SESSION_SECRET) return false;
  const [expiry, sig] = raw.split(".");
  if (!expiry || !sig || !/^\d+$/.test(expiry) || Number(expiry)<Date.now()) return false;
  return safeEqual(sig, await mac(expiry, env.SESSION_SECRET));
}
async function config(env) {
  try { return await env.LINKS.get(CONFIG_KEY, "json") || {url:"", delay:0, confirm:false}; }
  catch { return {url:"", delay:0, confirm:false}; }
}
function page(body, title=TITLE, status=200, headers={}) {
  return new Response(`<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="dark light"><title>${esc(title)}</title><style>
:root{font-family:system-ui,-apple-system,Segoe UI,sans-serif;color:#e5e7eb;background:#0b1120}*{box-sizing:border-box}body{margin:0;min-height:100vh;display:grid;place-items:center;padding:24px;background:radial-gradient(ellipse at top,#172554,#0b1120 65%)}main{width:min(100%,520px);background:#111827;border:1px solid #334155;border-radius:20px;padding:clamp(22px,5vw,36px);box-shadow:0 20px 70px #0005}h1{font-size:1.6rem;margin:0 0 8px}p{color:#cbd5e1;line-height:1.55}.muted{font-size:.9rem;color:#94a3b8}label{display:block;font-weight:650;margin:18px 0 7px}input[type=password],input[type=url],input[type=number]{width:100%;padding:12px 13px;border:1px solid #475569;border-radius:10px;background:#0f172a;color:#f8fafc;font:inherit}input[type=checkbox]{width:18px;height:18px;vertical-align:middle;margin-right:8px}button,.button{display:inline-block;border:0;border-radius:10px;background:#3b82f6;color:white;font-weight:700;font:inherit;padding:12px 16px;text-decoration:none;cursor:pointer;margin-top:20px}button:hover,.button:hover{background:#2563eb}.error{background:#7f1d1d55;border:1px solid #b91c1c;padding:10px;border-radius:9px}.ok{background:#14532d55;border:1px solid #15803d;padding:10px;border-radius:9px}.row{display:flex;gap:12px;align-items:center;justify-content:space-between;flex-wrap:wrap}.check{display:flex;gap:8px;align-items:center;font-weight:500}.check input{flex:none}.count{font-size:2.2rem;font-weight:800;color:#93c5fd}.line{height:6px;background:#334155;border-radius:8px;overflow:hidden;margin:18px 0}.line span{display:block;height:100%;background:#60a5fa;width:100%;transition:width 1s linear}a{color:#93c5fd}form{margin:0}
</style></head><body><main>${body}</main></body></html>`, {status,headers:{"content-type":"text/html; charset=utf-8","cache-control":"no-store",...headers}});
}
function adminForm(c, message="", isError=false) {
 return page(`<h1>⚙️ Paramètres de redirection</h1><p class="muted">Une seule destination pour ce site. La configuration est enregistrée dans le KV Cloudflare.</p>${message?`<p class="${isError?"error":"ok"}">${esc(message)}</p>`:""}<form method="post" action="/admin/save"><label for="url">Adresse de destination</label><input id="url" name="url" type="url" placeholder="https://cloud.example.com" value="${esc(c.url||"")}" required><label for="delay">Temps d’attente (secondes)</label><input id="delay" name="delay" type="number" min="0" max="300" value="${Math.max(0,Math.min(300,Number(c.delay)||0))}"><p class="muted">0 = aucun délai. Maximum : 300 secondes.</p><label class="check"><input type="checkbox" name="confirm" value="1" ${c.confirm?"checked":""}> Demander une confirmation avant de rediriger</label><button type="submit">Enregistrer</button></form><p class="muted">La page publique applique immédiatement ces paramètres.</p><form method="post" action="/admin/logout"><button type="submit" style="background:#475569">Se déconnecter</button></form>`, "Administration");
}
export default {
 async fetch(request, env) {
  const url = new URL(request.url), path = url.pathname;
  if (!env.LINKS || !env.ADMIN_PASSWORD || !env.SESSION_SECRET) return page(`<h1>Configuration incomplète</h1><p>Ajoutez le binding KV <code>LINKS</code> et les secrets <code>ADMIN_PASSWORD</code> et <code>SESSION_SECRET</code> dans Cloudflare Pages.</p>`, "Configuration requise", 500);
  if (path === "/admin/login" && request.method === "POST") {
   const form = await request.formData(), pw = String(form.get("password")||"");
   if (!safeEqual(pw, String(env.ADMIN_PASSWORD))) return page(`<h1>Administration</h1><p class="error">Mot de passe incorrect.</p><form method="post" action="/admin/login"><label for="password">Mot de passe</label><input id="password" name="password" type="password" required autofocus><button>Se connecter</button></form>`, "Connexion", 401);
   const expiry = String(Date.now()+8*60*60*1000), sig = await mac(expiry, env.SESSION_SECRET);
   return new Response("", {status:303,headers:{"Location":"/admin","Set-Cookie":`${COOKIE}=${expiry}.${sig}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=28800`,"Cache-Control":"no-store"}});
  }
  if (path === "/admin/logout" && request.method === "POST") return new Response("",{status:303,headers:{"Location":"/admin","Set-Cookie":`${COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=0`,"Cache-Control":"no-store"}});
  if (path === "/admin" || path.startsWith("/admin/")) {
   if (!await hasSession(request, env)) {
    if (path === "/admin/save") return new Response("Non autorisé",{status:401});
    return page(`<h1>Administration</h1><p>Entrez le mot de passe pour modifier la redirection.</p><form method="post" action="/admin/login"><label for="password">Mot de passe</label><input id="password" name="password" type="password" autocomplete="current-password" required autofocus><button type="submit">Se connecter</button></form>`, "Connexion");
   }
   if (path === "/admin/save" && request.method === "POST") {
    const f=await request.formData(); let target=String(f.get("url")||"").trim();
    try { const parsed=new URL(target); if (!["http:","https:"].includes(parsed.protocol)) throw new Error(); target=parsed.href; }
    catch { return adminForm(await config(env),"Adresse invalide : utilisez une URL complète en https:// ou http://.",true); }
    const delay=Math.max(0,Math.min(300,parseInt(String(f.get("delay")||"0"),10)||0));
    const c={url:target,delay,confirm:f.get("confirm")==="1"};
    try {
     if (!env.LINKS || typeof env.LINKS.put !== "function") throw new Error("Le binding KV LINKS est absent ou incorrect.");
     await env.LINKS.put(CONFIG_KEY,JSON.stringify(c));
     return adminForm(c,"Paramètres enregistrés.");
    } catch (err) {
     console.error("Erreur sauvegarde KV:", err);
     return adminForm(c,"Impossible d’enregistrer. Vérifiez dans Cloudflare Pages que le binding KV s’appelle exactement LINKS et qu’il est activé pour l’environnement Production/Preview utilisé. Consultez aussi Workers & Pages > Logs pour le détail technique.",true);
    }
   }
   return adminForm(await config(env));
  }
  const c=await config(env);
  if (!c.url) return page(`<h1>Redirection non configurée</h1><p>La destination n’a pas encore été définie.</p><a class="button" href="/admin">Ouvrir l’administration</a>`, "Redirection non configurée", 503);
  let destination;
  try { destination=new URL(c.url); if (!["http:","https:"].includes(destination.protocol)) throw new Error(); }
  catch { return page(`<h1>Destination invalide</h1><p>Contactez l’administrateur du site.</p>`, "Erreur", 500); }
  if (!c.confirm && Number(c.delay||0)===0) return Response.redirect(destination.href, 302);
  const delay=Math.max(0,Math.min(300,Number(c.delay)||0));
  const safeDest=esc(destination.href);
  const action=c.confirm?`<p>Vous allez être redirigé vers :</p><p><strong>${esc(destination.hostname)}</strong></p><a class="button" href="${safeDest}">Continuer</a>`:`<p>Vous allez être redirigé automatiquement dans <span class="count" id="count">${delay}</span> seconde(s).</p><div class="line"><span id="bar"></span></div>`;
  return page(`<h1>Vous allez être redirigé</h1>${action}<p class="muted"><a href="${safeDest}">Ouvrir directement la destination</a></p><script>const target=${JSON.stringify(destination.href)}, initial=${delay}, confirmMode=${c.confirm?"true":"false"};if(!confirmMode){let n=initial;const count=document.getElementById('count'),bar=document.getElementById('bar');bar.style.transitionDuration=initial+'s';requestAnimationFrame(()=>bar.style.width='0%');if(n<=0)location.replace(target);else{const t=setInterval(()=>{n--;count.textContent=n;if(n<=0){clearInterval(t);location.replace(target)}},1000)}}</script>`, "Redirection");
 }
};
